package com.effcode.clean.me.support;

public class SmtpHandler {

    public void post(SmtpEmail email) {
        System.out.println("Email posted: " + email);
    }
}

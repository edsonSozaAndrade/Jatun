# H1 Clean-me-up
The clean-me-up project is rather ugly and the task is to clean it up to make the code more maintainable.

The application exposes a REST end-point for sending email. 
The contract has not yet been published so you don't need to be backwards compatible.

When you are done you should be rather happy with code. 
If you left things behind - please note that down in a read me file.

Estimated time ~2 hours. 

You should only do changes in the **clean-me-up-rest** module, don't change the **clean-me-up-support** module.
